let btn = document.querySelector('.btn');
btn.onclick = function (e) {
    e.preventDefault();
    let background = document.querySelector('.header');
    background.classList.add('bgOnclick');
    document.querySelector('img.first-bg').src = './img/fbgOnclick.png'; 
}

$(function() {
    $(window).scroll(function() {
	    $('#future .section-title').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("zoomIn");
	        }
	    });
	});
	$(window).scroll(function() {
	    $('.facility').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("fadeInLeft");
	        }
	    });
    });
    $(window).scroll(function() {
	    $('.facility-travel').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("fadeInUp");
	        }
	    });
    });
    $(window).scroll(function() {
	    $('.facility-value').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("fadeInRight");
	        }
	    });
    });
    $(window).scroll(function() {
	    $('#order .btn').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("tada");
	        }
	    });
	});
	$(window).scroll(function() {
	    $('#order .section-title').each(function(){
	        var imagePos = $(this).offset().top;

	        var topOfWindow = $(window).scrollTop();
	        if (imagePos < topOfWindow+650) {
	            $(this).addClass("zoomIn");
	        }
	    });
	});
})

let facility = document.querySelector('.facility');
facility.onmouseover = function() {
facility.classList.add('facilityOnmouse');
}

let facilityTravel = document.querySelector('.facility-travel');
facilityTravel.onmouseover = function() {
facilityTravel.classList.add('facility-travelOnmouse');
}

let facilityValue = document.querySelector('.facility-value');
facilityValue.onmouseover = function() {
facilityValue.classList.add('facility-valueOnmouse');
}


let button = document.getElementById('button');
button.onclick = function() {
	let bgSectionOrder = document.querySelector('.order');
	bgSectionOrder.classList.add('bgOrderOnclick');
}


